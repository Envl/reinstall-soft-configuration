UnInstaller v1.7.3 - FS-plugin pro Total Commander 5.51 a v��e
----------------------------------------------------------------

Zdokonalen� plugin pro odinstalaci r�zn�ho software. Je podobn� jako Ovl�dac� panel - "P�idat/Odebrat programy", ale m� v�ce mo�nost� a je pohodln�j��.


Funkce:
------------
   - Zobrazit v�echny polo�ky pro odinstalaci program�
     (tak� skryt�) 
   - Odinstalovat program                        ("Enter")
   - Zobrazit v�echny vlastnosti polo�ky            ("F3" or "Ctrl-Q")
   - Smazat neplatn� odkazy                  ("Del" or "F8")
   - Editovat n�kter� vlastnosti polo�ky           ("Alt"+"Enter")
   - Konfigurace pluginu              ("Alt"+"Enter" v M�sta v  s�ti)


Instalace
------------
1. Rozbalte arch�v do pr�zdn� slo�ky
2. Vyberte Konfigurace - Nastaven� - Z�suvn� moduly - Moduly souborov�ch syst�m� (.WFX)
3. Klikn�te "P�idat"
4. Jd�te do slo�ky, kam jste rozbalili arch�v a vyberte UnInstTC.wfx
5. Klikn�te OK. Nyn� m��ete vybrat a pou��t plugin v "M�sta v s�ti".


S pozdravem
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru
Do �e�tiny p�elo�il: Pavel Zelen�
