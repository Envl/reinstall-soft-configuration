UnInstaller v1.8 - FS-plugin f�r Total Commander 5.51 und h�her
----------------------------------------------------------------

Erweitertes Plugin zum deinstallieren von Software. Ist identisch mit
Systemsteuerung Programme �ndern/entfernen, bietet aber mehr Funktionen

Eigenschaften:
------------
   - Show all records for uninstall program
   -Alle Entfernen Optionen
     (Auch versteckte)
   - Programm entfernen                        ("Enter")
   - Alle Eigentschaften anzeigen              ("F3" or "Ctrl-Q")
   - Fehlerhafte links entfernen               ("Del" or "F8")
   - Eigenschaften bearbeiten.                 ("Alt"+"Enter")
   - Plugin konfigurieren                      ("Alt"+"Enter" in der Netzwerkumgebung)


Installation
------------
1. Archiv in einem leeren Verzeichnis entpacken
2. Konfiguriren - Einstellungen - Plugin . Dateisystem Plugin -Konfigurieren
3. Auf hinzuf�gen klicken
4. UnInstTC.wfx ausw�hlen
5. Auf OK klicken. Nun ist das Plugin in der Netzwerkumgebung verf�gbar


Viel Spa�
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru
�bersetzt von Dirk Paehl -> http://www.paehl.de
