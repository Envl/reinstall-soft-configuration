procViewer plugin v1.5.1 beta for Total Commander

TThis plugin allows to view/kill processes that are running currently on the system. 
This plugin can view list of processes, kill ANY process (including system). 
F3 - Show memory usage, and loaded modules
F8 - kill process
ALT-ENTER (properties) show default win32 property dialog for main executable file (if it's available)

=======
ChangeLog
=======
28122012 1.5.1 uni
[*]32 and 64 files repacked to one zip

25122012 1.5.1 
[+] 32bit version
[+] first step on CustomColumns Support added PID column
[-] mostly remove ANSI support

1.4
[+] ALT-ENTER (properties) now show default win32 property dialog for main executable file (if it's available)

1.3
[*] fixed huge memleak, (thanks to tbeu for the report)
[*] significantly improved time to refresh (F2) of process list

1.1 
[+] F3 - show memory statistics and loaded modules
[*] minor unicode improvements 

1.0 beta - initial release